#include <stdio.h>

int main(void){

    int vet[100], i = 0;

    for (i == 0; i < 100; i++){
        vet[i] = i+1;
        printf("\nVetor[%d] = %d", i, vet[i]);
    }

    return 0;
}
