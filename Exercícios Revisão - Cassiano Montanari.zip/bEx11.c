#include <stdio.h>

    // Universidade T�cnol�gica Federal do Paran� - Algoritmos 02
    // Professor: Muriel

    // Lista 01 - Revis�o de Conte�dos
    // Parte C � Estrutura de repeti��o
    // Exerc�cio 11

    // Autor: Cassiano Guareschi Montanari
    // RA: 1343386

int main(void){

    char letra;
    int cont = 0;

    do{
        printf("\nInforme uma letra: ");
        scanf(" %c", &letra);
        cont++;
    }while(letra != 'a' && letra != 'A');

    printf("\n%d", cont);
    return 0;
}


