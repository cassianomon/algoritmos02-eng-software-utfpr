#include <stdio.h>

    // Universidade T�cnol�gica Federal do Paran� - Algoritmos 02
    // Professor: Muriel

    // Lista 01 - Revis�o de Conte�dos
    // Parte B � Estrutura de decis�o
    // Exerc�cio 07

    // Autor: Cassiano Guareschi Montanari
    // RA: 1343386

int main(void){

    int ano;

    printf("\nInforme um ano: ");
    scanf(" %d", &ano);

    if(((ano%4 == 0) && (ano%100 != 0)) || (ano%400 == 0)){
        printf("%d eh bissexto.", ano);
    } else {
        printf("%d nao eh bissexto.", ano);
    }

    return 0;
}

