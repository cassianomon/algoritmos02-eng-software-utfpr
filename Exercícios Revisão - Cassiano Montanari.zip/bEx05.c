#include <stdio.h>

    // Universidade T�cnol�gica Federal do Paran� - Algoritmos 02
    // Professor: Muriel

    // Lista 01 - Revis�o de Conte�dos
    // Parte B � Estrutura de decis�o
    // Exerc�cio 01

    // Autor: Cassiano Guareschi Montanari
    // RA: 1343386

int main(void){

    int a = 0, b = 0;

    printf("Informe o valor de A: ");
    scanf("%d", &a);

    printf("Informe o valor de B: ");
    scanf("%d", &b);

        if(a > b){
            printf("A eh maior que B");
        } else if (a < b){
            printf("A eh menor que B");
        } else if ( a == b) {
            printf("A eh igual a B");
        }

    printf("\n\n");

    return 0;
}

