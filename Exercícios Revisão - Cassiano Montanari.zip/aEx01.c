#include <stdio.h>

    // Universidade T�cnol�gica Federal do Paran� - Algoritmos 02
    // Professor: Muriel

    // Lista 01 - Revis�o de Conte�dos
    // Parte A � Estrutura sequencial
    // Exerc�cio 01

    // Autor: Cassiano Guareschi Montanari
    // RA: 1343386

int main(void){

    float a = 0, l = 0, c = 0, volume = 0;

    printf("Informe a altura: ");
    scanf("%f", &a);

    printf("Informe a largura: ");
    scanf("%f", &l);

    printf("Informe a comprimento: ");
    scanf("%f", &c);

    volume = a*l*c;

    printf("Volume: %.2f m3", volume);

    return 0;
}
