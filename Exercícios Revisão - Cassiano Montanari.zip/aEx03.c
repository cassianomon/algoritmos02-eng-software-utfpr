#include <stdio.h>

    // Universidade T�cnol�gica Federal do Paran� - Algoritmos 02
    // Professor: Muriel

    // Lista 01 - Revis�o de Conte�dos
    // Parte A � Estrutura sequencial
    // Exerc�cio 03

    // Autor: Cassiano Guareschi Montanari
    // RA: 1343386

int main(void){

    int valorA = 0, valorB = 0, aux = 0;

    printf("Informe o valor A: ");
    scanf("%d", &valorA);

    printf("Informe o valor B: ");
    scanf("%d", &valorB);

    printf("\n\nValores iniciais:\nA: %d \nB: %d", valorA, valorB);

    aux = valorA;
    valorA = valorB;
    valorB = aux;

    printf("\n\nValores finais:\nA: %d \nB: %d", valorA, valorB);

    return 0;
}
