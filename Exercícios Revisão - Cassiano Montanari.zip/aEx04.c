#include <stdio.h>

    // Universidade T�cnol�gica Federal do Paran� - Algoritmos 02
    // Professor: Muriel

    // Lista 01 - Revis�o de Conte�dos
    // Parte A � Estrutura sequencial
    // Exerc�cio 04

    // Autor: Cassiano Guareschi Montanari
    // RA: 1343386

float funcaoA(int x, int y);
float funcaoB(int x, int y);
float funcaoC(int x, int y);
float funcaoD(int x);
int funcaoE(int x, int y);
int funcaoF(int x);

int main(void){

    int xis = 0, ipsolom = 0;

    printf("Informe o valor de X: ");
    scanf("%d", &xis);

    printf("Informe o valor de Y: ");
    scanf("%d", &ipsolom);

    printf("\n\nValores iniciais:\nA: %d \nB: %d", xis, ipsolom);

    printf("\n\nFuncoes: \n");

    printf("\n\nA: %.2f", funcaoA(xis, ipsolom));

    printf("\n\nB: %.2f", funcaoB(xis, ipsolom));

    printf("\n\nC: %.2f", funcaoC(xis, ipsolom));

    printf("\n\nD: %.2f", funcaoD(xis));

    printf("\n\nE: %d", funcaoE(xis, ipsolom));

    printf("\n\nF: %d", funcaoF(xis));

    printf("\n\n");

    return 0;
}

float funcaoA(int x, int y){


    float result = (((float)(x + y)/y) * (x * x));
    return result;
}

float funcaoB(int x, int y){
    float result = ((float)(x+y) / (x-y));
    return result;
}

float funcaoC(int x, int y){
    float result = ((float)((x*x)+(y*y)) / 2);
    return result;
}

float funcaoD(int x){
    float result = ((float)(x*x*x)/(x*x));
    return result;
}

int funcaoE(int x, int y){
    int result = x % y;
    return result;
}

int funcaoF(int x){
    int result = x % 5;
    return result;
}
