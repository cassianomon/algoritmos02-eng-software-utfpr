#include <stdio.h>

    // Universidade T�cnol�gica Federal do Paran� - Algoritmos 02
    // Professor: Muriel

    // Lista 01 - Revis�o de Conte�dos
    // Parte C � Estrutura de repeti��o
    // Exerc�cio 08

    // Autor: Cassiano Guareschi Montanari
    // RA: 1343386

int main(void){

    int num = 0, i = 0;

    printf("\nInforme um numero: ");
    scanf("%d", &num);

    for (i = 0; i < num; i++) {
        if (num%i == 0 && i != num) {
            printf("\n%d nao eh primo", num);
            break;
        }else {
            printf("\n%d eh primo", num);
            break;
        }
    }

    return 0;
}

