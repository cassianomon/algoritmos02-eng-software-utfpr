#include <stdio.h>

    // Universidade T�cnol�gica Federal do Paran� - Algoritmos 02
    // Professor: Muriel

    // Lista 01 - Revis�o de Conte�dos
    // Parte A � Estrutura sequencial
    // Exerc�cio 02

    // Autor: Cassiano Guareschi Montanari
    // RA: 1343386

int main(void){

    float prestacao = 0, taxa = 0, valorFinal = 0;

    printf("Informe o valor da prestacao: ");
    scanf("%f", &prestacao);

    printf("Informe a taxa de juros: ");
    scanf("%f", &taxa);

    valorFinal = prestacao + (prestacao * taxa / 100);

    printf("Valor final: %.2f", valorFinal);

    return 0;
}
