#include <stdio.h>

    // Universidade T�cnol�gica Federal do Paran� - Algoritmos 02
    // Professor: Muriel

    // Lista 01 - Revis�o de Conte�dos
    // Parte C � Estrutura de repeti��o
    // Exerc�cio 10

    // Autor: Cassiano Guareschi Montanari
    // RA: 1343386

int main(void){

    int valorTotal = 0, valor = 0, i = 0;

    valor = 1000;

    do{
        valor = valor + ((valor * 5)/100);
        i++;
        if(valor >= 1200){
            printf("\n\nSerao necessarios %d meses para ultrapassar 1200 reais.\n\n\n", i);
        }
    }while(valor <= 1200);

    return 0;
}

