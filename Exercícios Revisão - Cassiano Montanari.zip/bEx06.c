#include <stdio.h>

    // Universidade T�cnol�gica Federal do Paran� - Algoritmos 02
    // Professor: Muriel

    // Lista 01 - Revis�o de Conte�dos
    // Parte B � Estrutura de decis�o
    // Exerc�cio 06

    // Autor: Cassiano Guareschi Montanari
    // RA: 1343386

int main(void){

    char letra;

    printf("\nInforme a letra: ");
    scanf(" %c", &letra);
    printf("%c", letra);

    if(letra == 'f' || letra == 'F'){
        printf("\nPessoa fisica");
    } else if (letra == 'j' || letra == 'J'){
        printf("\nPessoa juridica");
    } else {
        printf("\nTipo invalido");
    }

    return 0;
}

